package agenteviajero_heuristica;

import java.util.Scanner;
import java.util.ArrayList;
/**
 *
 * @author DARKUS
 */
public class Grafo {
    private double M[][];
    private int N;
    public Scanner sc = new Scanner(System.in);
    public Grafo(int n) {
        this.N=n;
        this.M = new double[n][n];
    }
    public  void llenarMatriz (){
        double arista;
        for (int i = 0; i<this.N; i++){
            for (int j = i+1; j<this.N; j++){
                System.out.print("Digite ["+i+"]["+j+"]=");
                do {
                    arista = sc.nextDouble(); 
                } while (arista<1);               
                  
                this.M[i][j] = arista;
                this.M[j][i] = arista;
            }
        }
    }
    public  void imprimirMatriz(){
        for (int i = 0; i < this.N; i++) {
            for (int j = 0; j < this.N; j++) {
                if (this.M[i][j]>0&&this.M[i][j]<999999999) {
                    System.out.print("|"+this.M[i][j]+"|\t");
                }else{
                    System.out.print("|∞|\t");
                }
                
            }
            System.out.println("");
        }
    }
    public  void imprimirMatriz(int m[][]){
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                System.out.print("|"+m[i][j]+"|\t");              
            }
            System.out.println("");
        }
    }
    public  void imprimirMatriz(double m[][]){
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[0].length; j++) {
                System.out.print("|"+m[i][j]+"|\t");              
            }
            System.out.println("");
        }
    }
    
    public double coloniaHormigas(){
        int nK,posIni;
        double alfa,beta,rhot;
        double [][]T;
        ArrayList<Double> solucion = new ArrayList();       
        do {
            System.out.print("Numero de hormigas:");
            nK= sc.nextInt();
        } while (nK<1);
        do {
            System.out.print("Alfa:");
            alfa = sc.nextDouble();
        } while (alfa<0);
        
        do {
            System.out.print("beta:");
        beta = sc.nextDouble();  
        } while (beta<1);        
            
        do {
            System.out.print("Constante de evaporacion:");
            rhot = sc.nextDouble();
        } while (!(rhot>=0.0&&rhot<=1.0));              
        do {
            System.out.print("Posicion inical:");
            posIni=sc.nextInt();
        } while (!(posIni>=0&&posIni<this.N));
        System.out.print("Feromona inicial:");
        T=crearFeromona(sc.nextDouble());//crea una cantidad de feromona dada por teclado en todas las rutas
        
        for (int i = 1; i <= this.N; i++) {
            /*matriz que guarda en memoria el recorrido de todas las hormigas por un punto y acumula 
            un valor que servira de factor para la matriz de feromona*/
            int [][]m = new int[this.N][this.N];
            for (int j=1;j <= nK;j++) {         
                //System.out.println("====Hormiga "+j+"=====");
                double x=0;//al empezar una hormiga el recorrido al inicio es 0
                int pos=posIni;//al empezar un recorrido cada hormiga inicia desde el punto inicial
                int[][] m2 = new int[this.N][this.N];//matriz de posicion
                for (int z = 0; z < this.N; z++) {//asigna 1 a la diagonal de la matriz de posiciones
                    m2[z][z]=1;
                }
                for (int k = 1; k <= this.N; k++) {                    
                    if (k==this.N) { //si no hay mas nodos disponibles se retorna al inicial y acumula 
                        x+=this.M[posIni][pos];
                    }else{
                        ArrayList <Double>p=new ArrayList();
                        ArrayList <Integer>pp=new ArrayList();           
                        double den=0;
                        for (int n = 0; n < this.N; n++) {
                            if (m2[pos][n]==0) {//si la posicion no ha sido recorrida(guardada en memoria)
                                den +=(Math.pow(T[pos][n], alfa)) * (Math.pow((1/this.M[pos][n]), beta));//calcula el denominador de la ecuacion de probabilidad
                            }                               
                        }
                        for (int l = 0; l < this.N; l++) {
                            if (m2[pos][l]==0) {
                                double num;
                                pp.add(l);//guarda en memoria las posiciones disponibles
                                num = Math.pow(T[pos][l], alfa) * Math.pow((1/this.M[pos][l]), beta);//calcula el numerador de la ecuacion de probabilidad                              
                                p.add(num/den);//calcula la probabilidad y la guarda en memoria
                                //System.out.println("Probabilidad:"+num/den);
                            }                                
                        }                       
                        int v=encontrarRango(p);//asigna a v la posicion de la lista promedio que fue escogida aleatoriamente                                               
                        //System.out.println("Rango escogido"+p.get(v));//
                        int y;
                        y=pp.get(v);//obtienen la posicion de la lista de posiciones promedio
                        x=x+this.M[pos][y];//acumula las rutas
                        m[pos][y]+=2;//asigna a la matriz un factor que servira, para aplicar  feromona en la matriz feromona
                        m[y][pos]+=2;
                        for (int l = 0; l < m2.length; l++) {//guarda en memoria el nodo que ya fue recorrido por la hormiga
                            m2[pos][l]=1;
                            m2[l][pos]=1;
                        }                       
                        pos=y;
                        //System.out.println("solucion hormiga "+j+":"+ x);//muestra el recorrido total de la hormiga                       
                    }                    
                }
                if (!solucion.contains(x)) {
                    solucion.add(x);
                } 
            }
            aplicarFeromona(T, m);
            actualizarFeromona(T, rhot);
        }
        double min,max=0;
        for (int i = 0; i < solucion.size(); i++) {
            if (max<solucion.get(i)) {
                max=solucion.get(i);
            }
        }
        min=max;
        for (int i = 0; i < solucion.size(); i++) {
            if (min>solucion.get(i)) {
                min=solucion.get(i);
            }
        }
        /*System.out.println("====FEROMONA===");
        imprimirMatriz(T);*/ //imprime la matriz de feromona
        return min;
    }
    //actualiza la feromona local de todas la rutas
    public void actualizarFeromona(double [][]T,double rhot){
        for (int i = 0; i < T.length; i++) {
            for (int j = i+1; j < T[0].length; j++) {
                T[i][j] = (1-rhot)*T[i][j];
                T[j][i] = (1-rhot)*T[j][i];
            }
        }
    }
    //aplica la feromona con respecto a un factor que se obtienen por el recorrido de las hormigas
    public void aplicarFeromona(double [][]T,int[][]m){
        for (int i = 0; i < T.length; i++) {
            for (int j = i+1; j < T[0].length; j++) {
                if (m[i][j]>0) {
                    T[i][j]*=m[i][j];
                    T[j][i]*=m[j][i];
                }
            }
        }
    }
    //crea feromona inicial en las posiciones exceputando la diagonal matriz de feromona.
    public double[][] crearFeromona(double x){
        double[][]y = new double[this.N][this.N];
        for (int i = 0; i < this.N; i++) {
            for (int j = i+1; j < this.N; j++) {
                y[i][j] = x;
                y[j][i] = x;
            }
        }
        return y;
    }
    
    //determina la que probabilidad se usara con respecto a un numero aleatorio 
    public int encontrarRango(ArrayList <Double> p){
        int n=0;
        double c=0;
        double r=Math.random();
        //System.out.println("Random:"+r);
        while(n<p.size()){
            c+=p.get(n);
            if (c>=r) {
                return n;
            }                                                        
            n++;
        }
        return 0;
    }
    
    public double[][] getM() {
        return M;
    }

    public void setM(double[][] M) {
        this.M = M;
    }

    public int getN() {
        return N;
    }

    public void setN(int N) {
        this.N = N;
    }
    
}
