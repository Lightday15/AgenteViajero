package agenteviajero_heuristica;

import java.util.Scanner;

/**
 *
 * @author DARKUS
 */
public class AgenteViajero_Heuristica {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        Grafo g;
        System.out.print("Numero de vertices:");
        do {
            n = sc.nextInt(); 
        } while (n<1);
        g = new Grafo(n);
        g.llenarMatriz();
        g.imprimirMatriz();
        double x=g.coloniaHormigas();
        System.out.println("Recorrido aproximado"+x);
    }    
}
